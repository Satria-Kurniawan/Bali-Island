@extends('layouts.frontend')

@section('title', 'Overview')

@section('bottom-content')
<div class="card-transparent">
    <div class="card-header">
        <h5>OVERVIEW</h5>
    </div>
    <div class="card-body">
        <p>
            Website ini merupakan sebuah website yang berisi informasi mengenai beberapa tempat/obejk wisata yang ada di
            Bali. Pada setiap konten halaman terdapat informasi masing-masing tempat wisata seperti : lokasi, daya
            tarik, dan lain-lain.
        </p>
    </div>
</div>
@endsection