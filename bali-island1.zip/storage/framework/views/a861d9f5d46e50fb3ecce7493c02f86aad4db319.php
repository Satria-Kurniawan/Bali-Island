

<?php $__env->startSection('bottom-content'); ?>

<div class="row">
    <div class="col-12">
        <?php $__currentLoopData = $post_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="konten-postingan/<?php echo e($item->id); ?>" class="text-dark">
            <div class="card-transparent mt-2 mb-2 border-bottom">
                <div class="row">
                    <div class="col-auto pb-2">
                        <img src="<?php echo e(asset('storage/' . $item->image)); ?>" style="height: 150px" width="150px">
                    </div>
                    <div class="col">
                        <div class="px-1">
                            <h4 class="card-title text-primary pb-2"><?php echo e($item->title); ?></h4>
                            <p class="card-text text-justify">
                                <?php echo e(Illuminate\Support\Str::limit($item->description, 200)); ?>

                            </p>
                            
                            <p class="card-text text-pink"><?php echo e($item->date); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bali-island\resources\views/post-searched.blade.php ENDPATH**/ ?>