<?php $__env->startSection('title', 'Welcome to Bali Island'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-8 pt-3">
            <div class="card rounded-0 shadow" style="height: 26rem">
                <div class="card-body p-0">
                    <?php $__currentLoopData = $post_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="konten-postingan/<?php echo e($item->id); ?>" class="text-dark">
                        <div class="img-gradient img-effect">
                            <img src="<?php echo e(asset('storage/' . $item->image)); ?>" style="height: 420px; width: 100%">
                        </div>
                        <div class="bottom-left img-effect">
                            <a href="konten-postingan/<?php echo e($item->id); ?>" class="text-white">
                                <h4 class="text-white">
                                    <?php echo e($item->title); ?>

                                </h4>
                                <p class="mb-0 text-white">
                                    <?php echo e($item->location); ?>

                                </p>
                                <p class="text-secondary">
                                    <?php echo e($item->date); ?>

                                </p>
                            </a>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="col-sm-4 pt-3">
            <div class="card rounded-0 mb-0 shadow" style="height: 12.8rem">
                <div class="card-body p-0">
                    <?php $__currentLoopData = $post_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="konten-postingan/<?php echo e($item->id); ?>" class="text-dark">
                        <div class="img-gradient img-effect">
                            <img src="<?php echo e(asset('storage/' . $item->image)); ?>" style="height: 207px; width: 365px;"
                                class="card-img-bottom embed-responsive-item">
                        </div>
                        <div class="bottom-left img-effect">
                            <a href="konten-postingan/<?php echo e($item->id); ?>" class="text-white">
                                <h4 class="text-white">
                                    <?php echo e($item->title); ?>

                                </h4>
                                <p class="mb-0 text-white">
                                    <?php echo e($item->location); ?>

                                </p>
                                <p class="text-secondary">
                                    <?php echo e($item->date); ?>

                                </p>
                            </a>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="card rounded-0 mt-2 shadow" style="height: 12.8rem">
                <div class="card-body p-0">
                    <?php $__currentLoopData = $post_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="konten-postingan/<?php echo e($item->id); ?>" class="text-dark">
                        <div class="img-gradient img-effect">
                            <img src="<?php echo e(asset('storage/' . $item->image)); ?>" style="height: 207px; width: 365px;">
                        </div>
                        <div class="bottom-left img-effect">
                            <a href="konten-postingan/<?php echo e($item->id); ?>" class="text-white">
                                <h4 class="text-white">
                                    <?php echo e($item->title); ?>

                                </h4>
                                <p class="mb-0 text-white">
                                    <?php echo e($item->location); ?>

                                </p>
                                <p class="text-secondary">
                                    <?php echo e($item->date); ?>

                                </p>
                            </a>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-content'); ?>
    
        <?php $__currentLoopData = $post_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="konten-postingan/<?php echo e($item->id); ?>" class="text-dark">
            <div class="card rounded-0 mr-3 float-left shadow" style="width: 20rem; margin-bottom: 100px">
                <div class="img-gradient img-effect">
                    <?php if(!empty($item->image)): ?>
                    <img src="<?php echo e(asset('storage/' . $item->image)); ?>" style="height: 200px" width="100%">
                    <?php else: ?>
                    No image available
                    <?php endif; ?>
                </div>
                <div class="bottom-right">
                    <h5 class="text-pink">
                        <?php echo e($item->title); ?>

                    </h5>
                    <div class="mb-0 text-black text-bold">
                        <?php echo e($item->location); ?>

                    </div>
                    <div class="text-secondary">
                        <?php echo e($item->date); ?>

                    </div>
                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagination-content'); ?>
    <div class="ml-1">
        <?php echo e($post_data->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bali-island\resources\views/welcome.blade.php ENDPATH**/ ?>