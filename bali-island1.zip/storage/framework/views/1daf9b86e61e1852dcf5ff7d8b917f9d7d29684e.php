

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Signika' rel='stylesheet'>

    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE-3.1.0/')); ?>/plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('AdminLTE-3.1.0/')); ?>/dist/css/adminlte.min.css">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/mystyle.css')); ?>">

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

</head>

<body class="sidebar-mini">

    <!-- Site wrapper -->
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white" style="font-family: Signika">
            <!-- Left navbar links -->
            <ul class="navbar-nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button">
                        <i class="fas fa-bars text-pink"></i>
                    </a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(url('/')); ?>" class="nav-link text-blue">Beranda</a>
                </li>
            </ul>

            <!-- Right navbar links -->
            <ul class="navbar-nav ml-auto">
                <!-- Navbar Search -->
                <li class="nav-item">
                    <a class="nav-link" data-widget="navbar-search" href="#" role="button">
                        <i class="fas fa-search text-pink"></i>
                    </a>
                    <div class="navbar-search-block">
                        <form class="form-inline" method="GET" action="<?php echo e(url('/postingan/pencarian')); ?>">
                            <div class="input-group input-group-sm">
                                <input class="form-control form-control-navbar" name="kueri" type="search"
                                    placeholder="Search" aria-label="Search">
                                <div class="input-group-append">
                                    <button class="btn btn-navbar" type="submit">
                                        <i class="fas fa-search text-blue"></i>
                                    </button>
                                    <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                                        <i class="fas fa-times text-pink"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </li>

                <li class="nav-item">
                    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
                        <i class="fas fa-expand-arrows-alt text-blue"></i>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#" role="button">
                        <i class="fas fa-th-large text-pink"></i>
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle text-blue" href="#" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            </ul>
        </nav>
        <!-- /.navbar -->
        <!-- Main Sidebar Container -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4" style="font-family: Signika">
            <!-- Brand Logo -->
            
            
            

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Sidebar Menu -->
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                        data-accordion="false">
                        <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
                        <li class="nav-item border-bottom">
                            <a href="#" class="nav-link text-blue">
                                <i class="fas fa-user"></i>
                                <p><?php echo e(Auth::user()->name); ?></p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('welcome')); ?>"
                                class="nav-link">
                                <i class="fas fa-window-restore" style="color:white"></i>
                                <p>| Beranda</p>
                            </a>
                        </li>
                        <li class="nav-item ">
                            <a href="<?php echo e(route('kategori')); ?>"
                                class="nav-link <?php echo e(Route::is('kategori') ? 'active' : ''); ?>">
                                <i class="fas fa-list" style="color: rgb(0, 195, 255)"></i>
                                <p>| Kategori</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('postingan')); ?>"
                                class="nav-link <?php echo e(Route::is('postingan') ? 'active' : ''); ?>">
                                <i class="fas fa-pager" style="color: rgb(115, 255, 0)"></i>
                                <p>| Manajemen Postingan</p>
                            </a>
                        </li>
                    </ul>
                </nav>
                <!-- /.sidebar-menu -->
            </div>
            <!-- /.sidebar -->
        </aside>


        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div><!-- /.container-fluid -->
            </section>

            

            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
                <!-- Control sidebar content goes here -->
            </aside>
            <!-- /.control-sidebar -->
        </div>
        <!-- ./wrapper -->

        <!-- jQuery -->
        <script src="<?php echo e(asset('AdminLTE-3.1.0/')); ?>/plugins/jquery/jquery.min.js"></script>
        <!-- Bootstrap 4 -->
        <script src="<?php echo e(asset('AdminLTE-3.1.0/')); ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo e(asset('AdminLTE-3.1.0/')); ?>/dist/js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo e(asset('AdminLTE-3.1.0/')); ?>/dist/js/demo.js"></script>
</body>

</html>

<script>
    <?php if(Session::has('success')): ?>
        toastr.options =
        {
        "closeButton" : true,
        "progressBar" : true
        }
        toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        toastr.options =
        {
        "closeButton" : true,
        "progressBar" : true
        }
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

    <?php if(Session::has('info')): ?>
        toastr.options =
        {
        "closeButton" : true,
        "progressBar" : true
        }
        toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>

    <?php if(Session::has('warning')): ?>
        toastr.options =
        {
        "closeButton" : true,
        "progressBar" : true
        }
        toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>

    // Image Priview
    $(document).ready(function(e) {


        $('#image').change(function() {

            let reader = new FileReader();

            reader.onload = (e) => {

                $('#preview-image-before-upload').attr('src', e.target.result);
            }

            reader.readAsDataURL(this.files[0]);

        });

    });

</script>
<?php /**PATH D:\Project\Laravel\bali-island\resources\views/layouts/app.blade.php ENDPATH**/ ?>