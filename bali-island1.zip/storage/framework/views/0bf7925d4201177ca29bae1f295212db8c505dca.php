

<?php $__env->startSection('title', 'Postingan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-3">Halaman Posts</h1>
        <div class="row justify-content-end">
            

            <form action="<?php echo e(route('createPost')); ?>">
                <button class="btn btn-success mr-2 mb-2">Create</button>
            </form>

            <div class="col-md-12">
                <div class="card rounded-0">
                    <div class="card-body">
                        <table class="table table-hover text-center">
                            <caption>List posts</caption>
                            <thead>
                                <tr>
                                    <th class="col-1">KATEGORI</th>
                                    <th class="col-2">JUDUL</th>
                                    <th class="col-2">DESKRIPSI</th>
                                    <th class="col-2">LOKASI</th>
                                    <th class="col-2">GAMBAR</th>
                                    <th class="col-2">TANGGAL</th>
                                    <th class="col-1">OPERATION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $post_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->category->category); ?></td>
                                        <td><?php echo e($item->title); ?></td>
                                        <td><?php echo e(Illuminate\Support\Str::limit($item->description, 40)); ?></td>
                                        <td><?php echo e(Illuminate\Support\Str::limit($item->location, 40)); ?></td>
                                        <td>
                                            <?php if(!empty($item->image)): ?>
                                                <img src="<?php echo e(asset('storage/' . $item->image)); ?>" class="img-fluid">
                                            <?php else: ?>
                                                No image available
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->date); ?></td>
                                        <td>
                                            <a href="edit-postingan/<?php echo e($item->id); ?>">
                                                <i class="fas fa-edit"></i>
                                            </a>|
                                            <a href="delete-postingan/<?php echo e($item->id); ?>"
                                                onclick="return confirm('Are you sure?')">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="">
                    <?php echo e($post_data->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bali-island\resources\views/posts.blade.php ENDPATH**/ ?>