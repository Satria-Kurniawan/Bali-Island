

<?php $__env->startSection('bottom-content'); ?>
    <div style="font-family: Nunito">
        <h4 class="text-center mt-2 mb-3"><?php echo e($post_data->title); ?></h4>
        <?php if(!empty($post_data->image)): ?>
        <img src="<?php echo e(asset('storage/' . $post_data->image)); ?>" style="height: 400px" width="100%">
        <?php else: ?>
        No image available
        <?php endif; ?>

        <h6><?php echo e($post_data->location); ?></h6>
        <p class="text-justify"><?php echo e($post_data->description); ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bali-island\resources\views/post-contents.blade.php ENDPATH**/ ?>