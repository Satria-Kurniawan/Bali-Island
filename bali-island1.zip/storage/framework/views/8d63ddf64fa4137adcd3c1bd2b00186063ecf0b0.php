

<?php $__env->startSection('title', 'Edit Kategori'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-3">Halaman Categories Edits</h1>
    <div class="row">
        <div class="col-md-7">
            <div class="card rounded-0">
                <div class="card-body">
                    <form action="<?php echo e(url('update-kategori/' . $category_data->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="">
                            <input type="hidden" name="id" id="id" value="<?php echo e($category_data['id']); ?>">
                            <label for="category" class="form-label">Kategori</label>
                            <input type="text" class="form-control" id="category" placeholder="Enter kategori"
                                name="category" value="<?php echo e($category_data['category']); ?>">
                        </div>
                        <button type="submit" class="btn btn-success mt-2 float-right">Save</button>
                    </form>
                </div>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bali-island\resources\views/category-edits.blade.php ENDPATH**/ ?>