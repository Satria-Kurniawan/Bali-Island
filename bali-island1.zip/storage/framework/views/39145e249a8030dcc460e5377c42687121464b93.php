

<?php $__env->startSection('title', 'Edit Postingan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-3">Halaman Edit Post</h1>
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card rounded-0">
                <div class="card-body">
                    <form action="<?php echo e(url('update-postingan/' . $post_data->id)); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" id="id" value="<?php echo e($post_data['id']); ?>">
                        <div class="form-group">
                            <label>Kategori</label>
                            <select class="form-control" id="category_id" name="category_id">
                                <option value disabled>Pilih</option>
                                <?php $__currentLoopData = $category_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($post_data->category_id === $item->id ||
                                    old('category_id') === $item->id): ?> selected <?php endif; ?>>
                                    <?php echo e($item->category); ?>

                                </option>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div>
                            <label for="title" class="form-label">Judul</label>
                            <input type="text" class="form-control" id="title" placeholder="Enter judul" name="title"
                                value="<?php echo e($post_data->title); ?>">
                        </div>
                        <div class="form-group mt-2">
                            <label for="description">Deskripsi</label>
                            <textarea class="form-control" id="description" name="description"
                                rows="3"><?php echo e($post_data->description); ?></textarea>
                        </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card rounded-0">
                <div class="card-body">
                    <div>
                        <label for="location" class="form-label">Lokasi</label>
                        <input type="text" class="form-control" id="location" placeholder="Enter lokasi" name="location"
                            value="<?php echo e($post_data->location); ?>">
                    </div>
                    <div class="form-group">
                        <label for="image">Gambar</label>
                        <input type="file" class="form-control-file" id="image" name="image">
                    </div>
                    <div>
                        <label for="date" class="form-label">Tanggal</label>
                        <input type="date" class="form-control" id="date" name="date" value="<?php echo e($post_data->date); ?>">
                    </div>
                    <div>
                        <p class="mb-0 mt-2"><label for="image_preview">Preview</label></p>
                        <img id="preview-image-before-upload" class="img-thumbnail col-4">
                    </div>
                    <button type="submit" class="btn btn-success mt-2 float-right">Save</button>
                    </form>
                </div>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bali-island\resources\views/post-edits.blade.php ENDPATH**/ ?>