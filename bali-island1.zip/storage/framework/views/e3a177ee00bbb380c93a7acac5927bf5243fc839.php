

<?php $__env->startSection('title', 'Kategori'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mb-3">Halaman Categories</h1>
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="card rounded-0">
                    <div class="card-body">
                        <form action="<?php echo e(route('storeCategory')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div>
                                <label for="category" class="form-label">Kategori</label>
                                <input type="text" class="form-control" id="category" placeholder="Enter kategori"
                                    name="category">
                            </div>
                            <button type="submit" class="btn btn-success mt-2 float-right">Submit</button>
                        </form>
                    </div>
                </div>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-5">
                <div class="card rounded-0">
                    <div class="card-body">
                        <table class="table table-hover text-center">
                            <caption>List categories</caption>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>KATEGORI</th>
                                    <th>OPERATION</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $category_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->category); ?></td>
                                        <td>
                                            <a href="edit-kategori/<?php echo e($item->id); ?>">
                                                <i class="fas fa-edit"></i>
                                            </a>|
                                            <a href="delete-kategori/<?php echo e($item->id); ?>"
                                                onclick="return confirm('Are you sure?')">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="">
                    <?php echo e($category_data->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bali-island\resources\views/categories.blade.php ENDPATH**/ ?>