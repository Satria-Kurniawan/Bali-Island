

<?php $__env->startSection('title', 'Galeri'); ?>

<?php $__env->startSection('bottom-content'); ?>

<div class="card-transparent border-bottom p-2 mt-2 mb-3">
    <h5>FOTO</h5>
</div>
<div class="row justify-content-center">
    

    <div id="carouselExampleIndicators" class="carousel slide mb-3" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        </ol>
        <div class="carousel-inner">
            <?php $__currentLoopData = $post_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                <img src="<?php echo e(asset('storage/' . $slider->image)); ?>" class="" alt="..." width="700px" height="450px">
                <div class="carousel-caption d-none d-md-block">
                    <h5><?php echo e($slider->title); ?></h5>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="fas fa-angle-left fa-3x" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="fas fa-angle-right fa-3x" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bali-island\resources\views/galeri.blade.php ENDPATH**/ ?>